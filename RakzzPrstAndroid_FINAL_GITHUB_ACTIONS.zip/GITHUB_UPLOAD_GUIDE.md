# Rakzz-Prst Android

Repository-ready Android project for GitHub Actions.

## Build APK
1. Upload the CONTENTS of this folder to the root of your GitHub repository.
2. Open the Actions tab.
3. Select "Build Rakzz-Prst APK".
4. Press "Run workflow" (or push to main/master).
5. After the workflow succeeds, open the run and download the artifact:
   Rakzz-Prst-debug-apk

The GitHub Actions workflow is in:
.github/workflows/build-apk.yml

Note: this workflow uses the Gradle executable available on the GitHub runner, so a Gradle Wrapper is not required.
