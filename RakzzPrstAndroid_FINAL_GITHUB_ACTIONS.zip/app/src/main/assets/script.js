function updateClock(){const now=new Date();const s=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(now);const el=document.getElementById('currentClock');if(el)el.textContent=s+' WIB'}
updateClock();setInterval(updateClock,1000);
'use strict';
let cart=[];
const seller='62881025002429', payment='0882008865036';
// Customer service menu
function toggleCustomerService(){
  const menu=document.getElementById('customerServiceMenu');
  const wrap=document.getElementById('customerServiceWrap');
  const btn=wrap?.querySelector('.customer-service-btn');
  if(!menu)return;
  const willOpen=menu.hidden;
  menu.hidden=!willOpen;
  if(btn)btn.setAttribute('aria-expanded',String(willOpen));
}
function openTelegramService(){
  // Telegram owner link belum diberikan. Tombol disiapkan agar link dapat dipasang tanpa mengubah desain.
  const telegramUrl='';
  if(telegramUrl){window.open(telegramUrl,'_blank','noopener,noreferrer');return;}
  alert('Link Telegram Customer Service belum diatur. Kirimkan link Telegram agar dapat dipasang.');
}
document.addEventListener('click',function(e){
  const wrap=document.getElementById('customerServiceWrap');
  const menu=document.getElementById('customerServiceMenu');
  if(wrap&&menu&&!wrap.contains(e.target)&&!menu.hidden){
    menu.hidden=true;
    const btn=wrap.querySelector('.customer-service-btn');
    if(btn)btn.setAttribute('aria-expanded','false');
  }
});

function money(n){return 'Rp '+Number(n).toLocaleString('id-ID')}
function isServiceOpen(){
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date());
  const h=Number(parts.find(x=>x.type==='hour').value), m=Number(parts.find(x=>x.type==='minute').value);
  const t=h*60+m; return t>=540 && t<1020;
}
function showClosedModal(){const m=document.getElementById('closedModal');if(m){m.classList.add('show');m.setAttribute('aria-hidden','false');document.body.classList.add('closed-open');}}
function closeClosedModal(){const m=document.getElementById('closedModal');if(m){m.classList.remove('show');m.setAttribute('aria-hidden','true');document.body.classList.remove('closed-open');}}
function closedNotice(){showClosedModal();}
function addToCart(name,period,price){
  if(!isServiceOpen()){closedNotice();return;}
  const item=cart.find(x=>x.name===name&&x.period===period);
  if(item)item.qty++; else cart.push({name,period,price:Number(price),qty:1});
  renderCart();
  document.getElementById('keranjang').scrollIntoView({behavior:'smooth',block:'center'});
}
function changeQty(i,d){cart[i].qty+=d;if(cart[i].qty<=0)cart.splice(i,1);renderCart()}
function total(){return cart.reduce((s,x)=>s+x.price*x.qty,0)}
function renderCart(){
 const box=document.getElementById('cartItems');
 document.getElementById('cartCount').textContent=cart.reduce((s,x)=>s+x.qty,0)+' item';
 document.getElementById('cartTotal').textContent=money(total());
 const cancelCartBtn=document.getElementById('cancelCartBtn');
 if(cancelCartBtn) cancelCartBtn.hidden=!cart.length;
 if(!cart.length){box.innerHTML='<p class="empty">Keranjang masih kosong.</p>';return}
 box.innerHTML=cart.map((x,i)=>`<div class="cartrow"><div><b>${x.name}</b><small>${x.period} • ${money(x.price)}</small></div><div class="qty"><button type="button" onclick="changeQty(${i},-1)">−</button><b>${x.qty}</b><button type="button" onclick="changeQty(${i},1)">+</button></div><strong>${money(x.price*x.qty)}</strong></div>`).join('');
}
function openCheckout(){if(!isServiceOpen()){closedNotice();return}if(!cart.length){alert('Keranjang masih kosong. Pilih layanan terlebih dahulu.');return}document.getElementById('summary').innerHTML=cart.map(x=>`${x.name} × ${x.qty} — ${money(x.price*x.qty)}`).join('<br>')+`<hr><b>Total Checkout: ${money(total())}</b>`;document.getElementById('formStep').hidden=false;document.getElementById('payStep').hidden=true;document.getElementById('modal').classList.add('show')}
function closeCheckout(){document.getElementById('modal').classList.remove('show')}
function showPayment(){const n=document.getElementById('name').value.trim(),p=document.getElementById('phone').value.trim();if(!n||!p){alert('Isi nama dan nomor WhatsApp terlebih dahulu.');return}window.checkoutCustomer={n,p};document.getElementById('formStep').hidden=true;document.getElementById('payStep').hidden=false}
function copyNumber(){navigator.clipboard?navigator.clipboard.writeText(payment).then(()=>alert('Nomor berhasil disalin.')).catch(()=>alert(payment)):alert(payment)}

function updateCheckoutPayment(){const m=document.querySelector('input[name=paymentMethod]:checked')?.value||'DANA';const q=document.getElementById('checkoutQrisInfo');if(q)q.hidden=m!=='QRIS'}

function cancelCartOrder(){
  if(!cart.length){alert('Belum ada pesanan yang dapat dibatalkan.');return;}
  const ok=confirm('Batalkan semua pesanan di keranjang? Semua item akan dihapus.');
  if(!ok)return;
  cart=[];
  window.checkoutCustomer=null;
  const name=document.getElementById('name');
  const phone=document.getElementById('phone');
  if(name)name.value='';
  if(phone)phone.value='';
  renderCart();
  closeCheckout();
  alert('Pesanan berhasil dibatalkan.');
}

function cancelOrder(){
  const ok=confirm('Batalkan pesanan ini? Item di keranjang akan dihapus.');
  if(!ok)return;
  cart=[];
  window.checkoutCustomer=null;
  const name=document.getElementById('name');
  const phone=document.getElementById('phone');
  if(name)name.value='';
  if(phone)phone.value='';
  closeCheckout();
  renderCart();
  alert('Pesanan berhasil dibatalkan.');
}
function confirmOrder(){if(!isServiceOpen()){closedNotice();return}const c=window.checkoutCustomer||{n:'-',p:'-'},method=document.querySelector('input[name=paymentMethod]:checked')?.value||'DANA',items=cart.map(x=>`• ${x.name} × ${x.qty} = ${money(x.price*x.qty)}`).join('%0A');const msg=`Halo Rakzz-Prst 👋%0A%0ASaya ingin memesan:%0A${items}%0A%0A• Total Checkout: ${money(total())}%0A• Nama: ${c.n}%0A• WhatsApp: ${c.p}%0A• Metode Pembayaran: ${method}%0A• Nomor pembayaran: ${payment}%0A%0ASaya sudah melakukan pembayaran. Mohon konfirmasi pesanan saya.`;window.open(`https://wa.me/${seller}?text=${msg}`,'_blank');
}
renderCart();

function updateServiceStatus(){
 const now=new Date();
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(now);
 const hour=Number(parts.find(x=>x.type==='hour').value);
 const minute=Number(parts.find(x=>x.type==='minute').value);
 const total=hour*60+minute;
 const start=9*60, end=17*60;
 const el=document.getElementById('serviceStatus'), text=document.getElementById('statusText');
 if(!el||!text)return;
 const active=total>=start && total<end;
 el.classList.toggle('active',active); el.classList.toggle('inactive',!active);
 text.textContent=active?'● PELAYANAN SEDANG AKTIF':'● PELAYANAN SEDANG TIDAK AKTIF';
}
updateServiceStatus(); setInterval(updateServiceStatus,60000);

const bgMusic=document.getElementById('bgMusic');
const musicToggle=document.getElementById('musicToggle');
const musicState=document.getElementById('musicState');
function toggleMusic(){if(!bgMusic)return;if(bgMusic.paused){bgMusic.play().then(()=>{musicToggle.textContent='❚❚';musicState.textContent='Sedang diputar'}).catch(()=>{musicState.textContent='Tekan lagi untuk memutar'});}else{bgMusic.pause();musicToggle.textContent='▶';musicState.textContent='Dijeda';}}
bgMusic?.addEventListener('ended',()=>{musicToggle.textContent='▶';musicState.textContent='Selesai'});

function updateGreeting(){
 const now=new Date();
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(now);
 const h=Number(parts.find(x=>x.type==='hour').value);
 const el=document.getElementById('greeting'); if(!el)return;
 let greeting;
 if(h>=4&&h<11) greeting='Selamat pagi 👋';
 else if(h>=11&&h<15) greeting='Selamat siang 👋';
 else if(h>=15&&h<18) greeting='Selamat sore 👋';
 else greeting='Selamat malam 👋';
 el.textContent=greeting+' — Selamat datang di Rakzz-Prst!';
}
updateGreeting(); setInterval(updateGreeting,60000);

// Indikator waktu sholat — dikembalikan seperti versi sebelumnya.
// Zona waktu: WIB (Asia/Jakarta). Jadwal di bawah adalah indikator sederhana,
// bukan pengganti jadwal resmi Kemenag/masjid setempat.
function updatePrayerStatus(){
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date());
 const h=Number(parts.find(x=>x.type==='hour').value), m=Number(parts.find(x=>x.type==='minute').value), t=h*60+m;
 const prayers=[
   ['Subuh',240,359,'04:00'],
   ['Dzuhur',720,899,'12:00'],
   ['Ashar',900,1079,'15:00'],
   ['Maghrib',1080,1139,'18:00'],
   ['Isya',1140,1439,'19:00'],
   ['Isya',0,239,'19:00']
 ];
 const current=prayers.find(x=>t>=x[1]&&t<=x[2]);
 const strip=document.getElementById('waktu-sholat');
 if(!strip)return;
 if(current){
   strip.hidden=false;
   document.getElementById('prayerTitle').textContent='Waktu Sholat';
   document.getElementById('prayerName').textContent=current[0];
   document.getElementById('prayerTime').textContent=current[3]+' WIB';
   document.getElementById('prayerNow').textContent='Sekarang: '+String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+' WIB';
   document.getElementById('prayerStatusText').textContent='Waktu '+current[0]+' sedang berlangsung';
 }else{
   strip.hidden=true;
 }
}
updatePrayerStatus();
setInterval(updatePrayerStatus,60000);


function makeTransactionId(){return 'RZ'+Date.now().toString().slice(-8)}
function loadTransactionHistory(){
  let history=JSON.parse(localStorage.getItem('rakzzTransactionHistory')||'[]');
  // Migrate an older single transaction into the history once.
  if(!history.length){
    const old=JSON.parse(localStorage.getItem('rakzzTransaction')||'null');
    if(old){history=[old];localStorage.setItem('rakzzTransactionHistory',JSON.stringify(history));localStorage.removeItem('rakzzTransaction');}
  }
  return Array.isArray(history)?history:[];
}
let transactionHistory=loadTransactionHistory();
function createTransaction(method){
 const c=window.checkoutCustomer||{n:'-',p:'-'};
 const tx={id:makeTransactionId(),name:c.n,phone:c.p,total:total(),method,createdAt:new Date().toISOString(),items:cart.map(x=>({name:x.name,period:x.period,price:x.price,qty:x.qty}))};
 transactionHistory.unshift(tx);
 transactionHistory=transactionHistory.slice(0,30);
 localStorage.setItem('rakzzTransactionHistory',JSON.stringify(transactionHistory));
 renderTransactionHistory();
 return tx;
}
function renderTransactionHistory(){
 const empty=document.getElementById('transactionEmpty'), box=document.getElementById('transactionHistory');
 if(!empty||!box)return;
 if(!transactionHistory.length){empty.hidden=false;box.innerHTML='';return}
 empty.hidden=true;
 box.innerHTML=transactionHistory.map(tx=>`<div class="history-card"><div class="history-top"><div><span class="tx-label">ID TRANSAKSI</span><b>${tx.id}</b></div><span class="history-method">${tx.method||'-'}</span></div><div class="history-details"><div><small>Nama</small><b>${tx.name||'-'}</b></div><div><small>Total</small><b>${money(tx.total)}</b></div><div><small>Metode</small><b>${tx.method||'-'}</b></div><div><small>Tanggal</small><b>${new Intl.DateTimeFormat('id-ID',{timeZone:'Asia/Jakarta',dateStyle:'short',timeStyle:'short'}).format(new Date(tx.createdAt))} WIB</b></div></div><div class="history-items">${(tx.items||[]).map(x=>`<div><span>${x.name} × ${x.qty}<small>${x.period}</small></span><b>${money(x.price*x.qty)}</b></div>`).join('')}</div></div>`).join('');
}
function clearTransactionHistory(){
 if(confirm('Hapus seluruh riwayat transaksi di perangkat ini?')){transactionHistory=[];localStorage.removeItem('rakzzTransactionHistory');localStorage.removeItem('rakzzTransaction');renderTransactionHistory();}
}
renderTransactionHistory();
const originalShowPayment=showPayment;
showPayment=function(){originalShowPayment();}
const originalConfirmOrder=confirmOrder;
confirmOrder=function(){
 if(!isServiceOpen()){closedNotice();return}
 const method=document.querySelector('input[name=paymentMethod]:checked')?.value||'DANA';
 createTransaction(method);
 originalConfirmOrder();
};
renderTransactionHistory();


/* ================= AKUN LOGIN LOKAL ================= */
const ACCOUNT_KEY='rakzzLocalAccount';
const SESSION_KEY='rakzzLoggedIn';
function loadAccount(){try{return JSON.parse(localStorage.getItem(ACCOUNT_KEY)||'null')}catch(e){return null}}
function isLoggedIn(){return localStorage.getItem(SESSION_KEY)==='1' && !!loadAccount()}
function cleanUsername(v){return (v||'').trim().replace(/\s+/g,' ')}
function switchAuth(mode){
 const l=document.getElementById('loginForm'),r=document.getElementById('registerForm');
 if(!l||!r)return;
 l.hidden=mode!=='login'; r.hidden=mode!=='register';
 document.getElementById('loginTab')?.classList.toggle('active',mode==='login');
 document.getElementById('registerTab')?.classList.toggle('active',mode==='register');
}
function registerUser(){
 const u=cleanUsername(document.getElementById('registerUsername')?.value), p=document.getElementById('registerPassword')?.value||'', p2=document.getElementById('registerPassword2')?.value||'';
 if(u.length<3){alert('Username minimal 3 karakter.');return}
 if(!/^[a-zA-Z0-9_.-]+$/.test(u)){alert('Username hanya boleh menggunakan huruf, angka, titik, garis bawah, atau tanda minus.');return}
 if(p.length<6){alert('Password minimal 6 karakter.');return}
 if(p!==p2){alert('Ulangi password harus sama.');return}
 if(loadAccount() && !confirm('Akun di perangkat ini sudah ada. Ganti akun tersebut?'))return;
 localStorage.setItem(ACCOUNT_KEY,JSON.stringify({username:u,password:p}));
 localStorage.setItem(SESSION_KEY,'1');
 localStorage.setItem(PROFILE_KEY,JSON.stringify({name:u,phone:'',username:u,updatedAt:new Date().toISOString()}));
 renderProfile(); alert('Akun berhasil dibuat dan kamu sudah login.');
}
function loginUser(){
 const u=cleanUsername(document.getElementById('loginUsername')?.value), p=document.getElementById('loginPassword')?.value||'', a=loadAccount();
 if(!a){alert('Belum ada akun. Pilih Daftar terlebih dahulu.');return}
 if(u!==a.username || p!==a.password){alert('Username atau password salah.');return}
 localStorage.setItem(SESSION_KEY,'1'); renderProfile(); alert('Login berhasil.');
}
function logoutUser(){
 if(!confirm('Keluar dari akun Rakzz-Prst?'))return;
 localStorage.removeItem(SESSION_KEY); renderProfile(); switchAuth('login');
}

/* ================= PENGGUNA & PROFIL ================= */
const PROFILE_KEY='rakzzUserProfile';
function loadProfile(){
  try{return JSON.parse(localStorage.getItem(PROFILE_KEY)||'null')}catch(e){return null}
}
function renderProfile(){
  const p=loadProfile();
  const auth=document.getElementById('authPanel'), logged=document.getElementById('profileLoggedIn');
  if(auth)auth.hidden=isLoggedIn(); if(logged)logged.hidden=!isLoggedIn();
  const a=loadAccount(); const userEl=document.getElementById('profileUsernameDisplay'); if(userEl)userEl.textContent=a?'@'+a.username:'';
  const nameEl=document.getElementById('profileNameDisplay');
  const phoneEl=document.getElementById('profilePhoneDisplay');
  const nameInput=document.getElementById('profileName');
  const phoneInput=document.getElementById('profilePhone');
  if(!nameEl||!phoneEl)return;
  nameEl.textContent=p?.name||'Pengguna Rakzz-Prst';
  phoneEl.textContent=p?.phone||'Belum ada nomor WhatsApp';
  if(nameInput)nameInput.value=p?.name||'';
  if(phoneInput)phoneInput.value=p?.phone||'';
}
function editProfile(){
  if(!isLoggedIn()){switchAuth('login'); document.getElementById('authPanel')?.scrollIntoView({behavior:'smooth',block:'center'}); alert('Silakan login terlebih dahulu.'); return}
  const form=document.getElementById('profileForm');
  if(!form)return;
  renderProfile(); form.hidden=false;
  document.getElementById('profileName')?.focus();
}
function closeProfileEditor(){const form=document.getElementById('profileForm');if(form)form.hidden=true;}
function saveProfile(){
  const name=(document.getElementById('profileName')?.value||'').trim();
  const phone=(document.getElementById('profilePhone')?.value||'').trim();
  if(!name){alert('Silakan isi nama pengguna.');return}
  if(phone.length<8){alert('Silakan isi nomor WhatsApp yang valid.');return}
  localStorage.setItem(PROFILE_KEY,JSON.stringify({name,phone,username:(loadAccount()?.username||''),updatedAt:new Date().toISOString()}));
  const checkoutName=document.getElementById('name');
  const checkoutPhone=document.getElementById('phone');
  if(checkoutName)checkoutName.value=name;
  if(checkoutPhone)checkoutPhone.value=phone;
  renderProfile(); closeProfileEditor(); alert('Profil berhasil disimpan.');
}
function goToSection(id){document.getElementById(id)?.scrollIntoView({behavior:'smooth',block:'start'});}
function applyProfileToCheckout(){
  const p=loadProfile();
  if(!p)return;
  const n=document.getElementById('name'), ph=document.getElementById('phone');
  if(n&&!n.value)n.value=p.name||'';
  if(ph&&!ph.value)ph.value=p.phone||'';
}
renderProfile();
const _openCheckout=window.openCheckout;
if(typeof _openCheckout==='function'){
  window.openCheckout=function(){if(!isLoggedIn()){document.getElementById('profil')?.scrollIntoView({behavior:'smooth',block:'center'}); switchAuth('login'); alert('Silakan login terlebih dahulu sebelum checkout.'); return} _openCheckout();setTimeout(applyProfileToCheckout,30);};
}
