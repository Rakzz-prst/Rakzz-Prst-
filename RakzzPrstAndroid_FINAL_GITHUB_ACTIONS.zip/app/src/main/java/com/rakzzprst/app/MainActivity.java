package com.rakzzprst.app;

import android.animation.ValueAnimator;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.content.*;
import android.net.*;
import android.webkit.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    WebView w;
    MediaPlayer startupPlayer;

    private static final long SPLASH_TOTAL_MS = 2400;
    private static final long AUDIO_FADE_START_MS = 1400;
    private static final long AUDIO_FADE_DURATION_MS = 1000;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        final FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(6,16,27));

        w = new WebView(this);
        w.setAlpha(0f);
        root.addView(w, new FrameLayout.LayoutParams(-1, -1));

        final LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(40, 40, 40, 40);
        splash.setBackgroundColor(Color.rgb(6,16,27));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.rakzzprst.app.R.drawable.rakzz_prst_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        GradientDrawable circleBg = new GradientDrawable();
        circleBg.setShape(GradientDrawable.OVAL);
        circleBg.setColor(Color.argb(35,22,194,255));
        circleBg.setStroke(2, Color.argb(130,22,194,255));
        logo.setBackground(circleBg);
        logo.setPadding(28,28,28,28);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(190,190);
        splash.addView(logo, lp);

        TextView title = new TextView(this);
        title.setText("Rakzz-Prst");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setAlpha(0f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2,-2);
        tp.topMargin = 22;
        splash.addView(title,tp);

        TextView sub = new TextView(this);
        sub.setText("Premium Apps • Jasa Edit");
        sub.setTextColor(Color.rgb(160,190,205));
        sub.setTextSize(14);
        sub.setGravity(Gravity.CENTER);
        sub.setAlpha(0f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2,-2);
        sp.topMargin = 8;
        splash.addView(sub,sp);

        root.addView(splash, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);

        // Smooth opening animation
        logo.setScaleX(0.65f);
        logo.setScaleY(0.65f);
        logo.setAlpha(0f);
        logo.animate()
                .alpha(1f)
                .scaleX(1.08f)
                .scaleY(1.08f)
                .setDuration(650)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() ->
                        logo.animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .setDuration(350)
                                .start()
                )
                .start();

        title.animate().alpha(1f).setStartDelay(350).setDuration(500).start();
        sub.animate().alpha(1f).setStartDelay(550).setDuration(500).start();

        // Play the user's selected sound during the splash.
        // It fades smoothly to silence as the splash animation ends.
        try {
            startupPlayer = MediaPlayer.create(this, R.raw.startup_sound);
            if (startupPlayer != null) {
                startupPlayer.setVolume(0.75f, 0.75f);
                startupPlayer.setLooping(false);
                startupPlayer.start();

                ValueAnimator fade = ValueAnimator.ofFloat(0.75f, 0f);
                fade.setStartDelay(AUDIO_FADE_START_MS);
                fade.setDuration(AUDIO_FADE_DURATION_MS);
                fade.addUpdateListener(animation -> {
                    if (startupPlayer != null) {
                        float volume = (Float) animation.getAnimatedValue();
                        try {
                            startupPlayer.setVolume(volume, volume);
                        } catch (Exception ignored) {}
                    }
                });
                fade.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(android.animation.Animator animation) {
                        releaseStartupPlayer();
                    }
                });
                fade.start();
            }
        } catch (Exception ignored) {}

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view, String url){
                view.evaluateJavascript("document.body.classList.add('android-app'); if(!document.querySelector('.app-bottom-nav')){var n=document.createElement('div'); n.className='app-bottom-nav'; n.innerHTML='<a class=\"active\" href=\"#home\"><span>⌂</span>Beranda</a><a href=\"#layanan\"><span>▦</span>Layanan</a><a href=\"#keranjang\"><span>🛒</span>Keranjang</a><a href=\"#pembayaran\"><span>💳</span>Bayar</a>'; document.body.appendChild(n);}", null);
            }
            public boolean shouldOverrideUrlLoading(WebView v,String u){
                if(u.startsWith("http")){
                    startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));
                    return true;
                }
                return false;
            }
        });
        w.loadUrl("file:///android_asset/index.html");

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            w.animate().alpha(1f).setDuration(450).start();
            splash.animate()
                    .alpha(0f)
                    .setDuration(450)
                    .withEndAction(() -> root.removeView(splash))
                    .start();
        }, 1950);
    }

    private void releaseStartupPlayer() {
        if (startupPlayer != null) {
            try {
                if (startupPlayer.isPlaying()) startupPlayer.stop();
            } catch (Exception ignored) {}
            try {
                startupPlayer.release();
            } catch (Exception ignored) {}
            startupPlayer = null;
        }
    }

    @Override protected void onDestroy(){
        releaseStartupPlayer();
        if(w != null) w.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed(){
        if(w.canGoBack()) w.goBack();
        else super.onBackPressed();
    }
}
